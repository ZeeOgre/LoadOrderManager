namespace ZO.LOM.App
{
    public partial class LoadOrderWindowViewModel
    {
        // Helper methods
        private bool CanExecuteSave() { }
        private bool CanMoveUp() { }
        private bool CanMoveDown() { }
        private bool CanExecuteEdit(object parameter) { }
        private bool CanExecuteCopyText(object parameter) { }
        private bool CanExecuteChangeGroup(object parameter) { }
        private bool CanExecuteToggleEnable(object parameter) { }
        private bool CanExecuteDelete(object parameter) { }
    }
}
